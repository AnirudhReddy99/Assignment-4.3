// Initialize express router
let router = require('express').Router();

// Set default API response
router.get('/', function(req, res) {
    res.json({
        status: 'API Works',
        message: 'Welcome to Music API'
    });
});

// Import Music Controller
var musicController = require('./musicController');

// Music routes
router.route('/music')
    .get(musicController.index)
    .post(musicController.add);

router.route('/music/:music_id')
    .get(musicController.view)
    .patch(musicController.update)
    .put(musicController.update)
    .delete(musicController.delete);

// Export API routes
module.exports = router;
