// Import Music Model
const Music = require('./musicModel');

// For index
exports.index = function (req, res) {
    Music.find().lean().exec()
        .then(musicList => {
            res.json({
                status: "success",
                message: "Music Details Successfully Retrieved!",
                data: musicList
            });
        })
        .catch(err => {
            res.status(500).json({
                status: "error",
                message: "Failed to retrieve music details",
                error: err
            });
        });
};



exports.add = async function (req, res) {
    try {
        var music = new Music();
        music.title = req.body.title;
        music.artist = req.body.artist;
        music.album = req.body.album;
        music.genre = req.body.genre;
        music.year = req.body.year;
        music.duration = req.body.duration;

        // Save and check for errors
        const savedMusic = await music.save();
        res.json({
            message: "New Music Detail Added!",
            data: savedMusic
        });
    } catch (err) {
        res.status(500).json(err);
    }
};

// View Music Detail
exports.view = function (req, res) {
    Music.findById(req.params.music_id)
        .then(music => {
            if (!music) {
                return res.status(404).json({
                    status: "error",
                    message: "Music not found"
                });
            }
            res.json({
                status: "success",
                message: "Music Details",
                data: music
            });
        })
        .catch(err => {
            res.status(500).json({
                status: "error",
                message: "Failed to retrieve music details",
                error: err
            });
        });
};


// Update Music Detail
exports.update = function (req, res) {
    Music.findByIdAndUpdate(req.params.music_id, {
        $set: {
            title: req.body.title,
            artist: req.body.artist,
            album: req.body.album,
            genre: req.body.genre,
            year: req.body.year,
            duration: req.body.duration
        }
    }, { new: true, useFindAndModify: false }, function (err, music) {
        if (err) {
            console.error("Error updating music details:", err);
            res.json(err);
        } else {
            console.log("Music details updated successfully:", music);
            res.json({
                message: "Updated Music Details Successfully",
                data: music
            });
        }
    });
};

// Delete Music Detail
exports.delete = function (req, res) {
    Music.deleteOne({
        _id: req.params.music_id
    }, function (err, result) {
        if (err)
            res.send(err)
        res.json({
            status: "success",
            message: 'Deleted Music Details'
        });
    });
};
