var mongoose = require('mongoose');

// schema
var musicSchema = mongoose.Schema({
    title: {
        type: String,
        required: true
    },
    artist: {
        type: String,
        required: true
    },
    album: {
        type: String,
        required: true
    },
    genre: {
        type: String,
        required: true
    },
    year: {
        type: Number,
        required: true
    },
    duration: {
        type: Number,
        required: true // Duration in seconds
    },
    // You can add more fields as per your requirement
    created_at: {
        type: Date,
        default: Date.now
    }
});

// Export Music Model
var Music = module.exports = mongoose.model('music', musicSchema);

module.exports.get = function() {
    return Music.find().exec();
}

