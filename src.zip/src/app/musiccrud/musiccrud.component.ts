import { Component } from '@angular/core';

@Component({
  selector: 'app-musiccrud',
  standalone: true,
  imports: [],
  templateUrl: './musiccrud.component.html',
  styleUrl: './musiccrud.component.scss'
})
export class MusiccrudComponent {
  title: string ="";
  artist: string ="";
  album: string ="";
  genre: string ="";
  year ="";
  duration ="";

}
