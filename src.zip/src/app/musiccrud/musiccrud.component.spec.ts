import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MusiccrudComponent } from './musiccrud.component';

describe('MusiccrudComponent', () => {
  let component: MusiccrudComponent;
  let fixture: ComponentFixture<MusiccrudComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [MusiccrudComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(MusiccrudComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
