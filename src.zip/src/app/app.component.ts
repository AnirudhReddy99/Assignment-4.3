import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { MusiccrudComponent } from "./musiccrud/musiccrud.component";

@Component({
    selector: 'app-root',
    standalone: true,
    templateUrl: './app.component.html',
    styleUrl: './app.component.scss',
    imports: [RouterOutlet, MusiccrudComponent]
})
export class AppComponent {
  title = 'front-end';
}
